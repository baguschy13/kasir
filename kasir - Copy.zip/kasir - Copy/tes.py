import os
from flask import Flask, request, redirect, url_for, flash
from flask_mail import Mail, Message

app = Flask(__name__)

# Konfigurasi aplikasi Flask
app.config['SECRET_KEY'] = 'coog zlns uszb yhxw'  # Ganti dengan kunci rahasia Anda
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = 'baguschy14@gmail.com'  # Ganti dengan alamat email Anda
app.config['MAIL_PASSWORD'] = 'coog zlns uszb yhxw'   # Ganti dengan kata sandi aplikasi khusus
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False

mail = Mail(app)

@app.route('/')
def index():
    return '''
        <form action="/send-email" method="post">
            <input type="email" name="to" placeholder="Email Penerima" required>
            <input type="text" name="subject" placeholder="Subjek" required>
            <textarea name="message" placeholder="Pesan" required></textarea>
            <button type="submit">Kirim Email</button>
        </form>
    '''

@app.route('/send-email', methods=['POST'])
def send_email():
    recipient = request.form['to']
    subject = request.form['subject']
    message_body = request.form['message']

    msg = Message(subject=subject,
                  sender=app.config['MAIL_USERNAME'],
                  recipients=[recipient],
                  body=message_body)

    try:
        mail.send(msg)
        flash('Email berhasil dikirim!', 'success')
    except Exception as e:
        # Tambahkan log kesalahan
        print(f'Error: {str(e)}')
        flash(f'Kesalahan saat mengirim email: {str(e)}', 'error')

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
