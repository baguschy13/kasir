from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy.orm import joinedload
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask_mail import Mail, Message

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cashier.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'mysecret'
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = 'your_email@gmail.com'  # Ganti dengan alamat email Anda
app.config['MAIL_PASSWORD'] = 'your_app_password'  # Ganti dengan kata sandi aplikasi khusus
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False

db = SQLAlchemy(app)
mail = Mail(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Item(db.Model):
    id = db.Column(db.String(80), primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    stock = db.Column(db.Integer, nullable=False)
    distributor_price = db.Column(db.Float, nullable=False)
    selling_price = db.Column(db.Float, nullable=False)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.String(80), db.ForeignKey('item.id'), nullable=False)
    item_name = db.Column(db.String(80), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    buyer_name = db.Column(db.String(100))
    buyer_phone = db.Column(db.String(20))
    buyer_email = db.Column(db.String(100))

    item = db.relationship('Item', backref=db.backref('transactions', lazy=True))

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Silakan login terlebih dahulu.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if User.query.filter_by(username=username).first():
            flash('Username sudah ada.', 'error')
            return redirect(url_for('register'))

        user = User(username=username)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        flash('Registrasi berhasil!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            flash('Login berhasil!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Username atau password salah.', 'error')
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logout berhasil!', 'success')
    return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    items = Item.query.all()
    return render_template('index.html', items=items)

@app.route('/add_item', methods=['POST'])
@login_required
def add_item():
    item_id = request.form.get('id')
    item_name = request.form.get('item')
    item_stock = request.form.get('stock')
    item_distributor_price = request.form.get('distributor_price')
    item_selling_price = request.form.get('selling_price')

    existing_item = Item.query.filter_by(id=item_id).first()
    if existing_item:
        flash('Item dengan ID ini sudah ada. Barang tidak ditambahkan.', 'error')
        return redirect(url_for('index'))

    new_item = Item(
        id=item_id,
        name=item_name,
        stock=int(item_stock),
        distributor_price=float(item_distributor_price),
        selling_price=float(item_selling_price)
    )
    db.session.add(new_item)
    db.session.commit()
    flash('Item berhasil ditambahkan!', 'success')
    return redirect(url_for('index'))

@app.route('/delete_item/<item_id>', methods=['POST'])
@login_required
def delete_item(item_id):
    item = Item.query.get(item_id)
    if item:
        db.session.delete(item)
        db.session.commit()
        flash('Item berhasil dihapus!', 'success')
    else:
        flash('Item tidak ditemukan.', 'error')
    return redirect(url_for('index'))

@app.route('/update_stock', methods=['POST'])
@login_required
def update_stock():
    item_id = request.form.get('id')
    additional_stock = request.form.get('additional_stock')

    item = Item.query.get(item_id)
    if item:
        item.stock += int(additional_stock)
        db.session.commit()
        flash('Stok berhasil diperbarui!', 'success')
    else:
        flash('Item tidak ditemukan.', 'error')
    return redirect(url_for('index'))

@app.route('/cashier', methods=['GET', 'POST'])
@login_required
def cashier():
    if request.method == 'POST':
        item_ids = request.form.getlist('item_ids')
        item_names = request.form.getlist('item_names')
        quantities = request.form.getlist('quantities')
        buyer_name = request.form.get('buyer_name')
        buyer_phone = request.form.get('buyer_phone')
        buyer_email = request.form.get('buyer_email')

        purchased_items = []
        total_price = 0
        errors = []

        items = {item.id: item for item in Item.query.filter(Item.id.in_(item_ids)).options(joinedload(Item.transactions)).all()}

        for item_id, item_name, quantity in zip(item_ids, item_names, quantities):
            item = items.get(item_id)
            if not item:
                errors.append(f'Item dengan ID {item_id} tidak ditemukan.')
                continue
            if item.stock < int(quantity):
                errors.append(f'Stok untuk item {item_id} tidak mencukupi.')
                continue

            total_item_price = item.selling_price * int(quantity)
            total_price += total_item_price

            purchased_items.append({
                'id': item.id,
                'name': item.name,
                'quantity': int(quantity),
                'price': item.selling_price,
                'total': total_item_price
            })

            item.stock -= int(quantity)
            db.session.commit()

            transaction = Transaction(
                item_id=item.id,
                item_name=item.name,
                quantity=int(quantity),
                total_price=total_item_price,
                buyer_name=buyer_name,
                buyer_phone=buyer_phone,
                buyer_email=buyer_email
            )
            db.session.add(transaction)
            db.session.commit()

        if errors:
            for error in errors:
                flash(error, 'error')
        else:
            flash('Transaksi berhasil dihitung!', 'success')

        return render_template('cashier.html', purchased_items=purchased_items, total_price=total_price, buyer_name=buyer_name, buyer_phone=buyer_phone, buyer_email=buyer_email)

    return render_template('cashier.html')

@app.route('/send_receipt', methods=['POST'])
@login_required
def send_receipt():
    recipient = request.form.get('buyer_email')
    subject = "Rincian Pembelian Anda"
    message_body = f"""
    Nama Pembeli: {request.form.get('buyer_name')}
    Nomor Telepon: {request.form.get('buyer_phone')}
    Email: {request.form.get('buyer_email')}
    
    Rincian Pembelian:
    {request.form.get('purchased_items')}
    
    Total Harga: {request.form.get('total_price')}
    """

    msg = Message(subject=subject,
                  sender=app.config['MAIL_USERNAME'],
                  recipients=[recipient],
                  body=message_body)

    try:
        mail.send(msg)
        flash('Email berhasil dikirim!', 'success')
    except Exception as e:
        flash(f'Kesalahan saat mengirim email: {str(e)}', 'error')

    return redirect(url_for('cashier'))

@app.route('/sales_report', methods=['GET'])
@login_required
def sales_report():
    transactions = Transaction.query.all()

    daily_reports = {}
    for transaction in transactions:
        date = transaction.timestamp.date()
        if date not in daily_reports:
            daily_reports[date] = {
                'transaction_count': 0,
                'total_quantity': 0,
                'total_price': 0
            }
        daily_reports[date]['transaction_count'] += 1
        daily_reports[date]['total_quantity'] += transaction.quantity
        daily_reports[date]['total_price'] += transaction.total_price

    daily_reports_list = [{'date': date, **data} for date, data in daily_reports.items()]

    return render_template('sales_report.html', daily_reports=daily_reports_list)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
